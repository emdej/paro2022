#include <iterator>
#include <iostream>
#include <array>

/**
 * As-if rule
 * https://en.cppreference.com/w/cpp/language/as_if
*/
void as_if_test()
{
    { // this loop can be deleted
        int end = 5;
        while (end--)
        {
        }
    }

    { // this loop can't be deleted
        volatile int end = 5;
        while (end--)
        {
        }
    }

    { // this loop can't be deleted
        int end = 5;
        while (end++)
        {
        }
    }
}

int glob_a = 5;
int glob_b = 10;

int glob_arr[100];

// C++ assumes single threaded code, so evaluation of some expressions may be elided
// if they don't produce visible side effect locally
void as_if_test2()
{
    glob_a = 15;
    glob_b = glob_a;

    for (int i{}; i < 100; ++i)
    {
        glob_arr[i] = i;
    }

    glob_a = 10;
}

/**
 * Inline'ing + as-if rule
*/

int glob_eval = 10;

[[gnu::always_inline]] void eval1()
{
    glob_eval = 10 * 10 * glob_eval;
}

[[gnu::always_inline]] void eval2()
{
    glob_eval = 10 * 10 * glob_eval;
}

void as_if_test3()
{
    eval1();
    eval2();
}

/**
 * Disobeying as-if rule
 */
volatile int a_disobey{10};

void as_if_disobey()
{
    a_disobey = 10 * 10 * a_disobey;
    a_disobey = 10 * 10 * a_disobey;
}

#include <atomic>

std::atomic<int> atomic_disobey{10};

void as_if_disobey_atomic()
{
    atomic_disobey = 10 * 10 * atomic_disobey;
    atomic_disobey = 10 * 10 * atomic_disobey;
}

// + other TU without LTO and with LTO

/**
 * Breaking the as-if rule
 * 
 * Copy ellision + RVO
*/

struct A
{
    A()
    {
        std::cout << "created" << std::endl;
    }

    A(A &&)
    {
        std::cout << "moved" << std::endl;
    }
};

[[gnu::noinline]] auto as_if_break()
{
    return A(A(A(A(A(A(A()))))));
}

/**
 * evaluation of expression -- value computations (computed value of expression) + side effect
 *
 * As-if rule + evaluation order in action
 * 
 * So guarantees about as-if behaviour
 * https://en.cppreference.com/w/cpp/language/eval_order
 * 
 */

int a_eval()
{
    std::cout << "a_eval" << std::endl;

    return 0;
}

int b_eval()
{
    std::cout << "b_eval" << std::endl;

    return 1;
}

int c_eval()
{
    std::cout << "c_eval" << std::endl;

    return 2;
}

void eval_tester(int a, int b, int c) {}

[[gnu::noinline]] void eval_order_test()
{
    a_eval(), b_eval(), c_eval();
    auto x = a_eval() * b_eval() * c_eval();
    eval_tester(a_eval(), b_eval(), c_eval());
}

/**
 * adding of vectors vectorized + restrict (as-if rule optimizations)
 * https://en.cppreference.com/w/c/language/restrict
 * https://en.cppreference.com/w/cpp/language/reinterpret_cast#Type_aliasing
*/

constexpr auto test_size = 64;

[[gnu::noinline]] void add_vectors(float (&a)[test_size], float (&b)[test_size], float (&c)[test_size]) noexcept
{
    for (int idx{}; idx < test_size; ++idx)
    {
        c[idx] = a[idx] + b[idx];
    }
}

[[gnu::noinline]] void add_vectors_restrict(float (&__restrict__ a)[test_size], float (&__restrict__ b)[test_size], float (&__restrict__ c)[test_size]) noexcept
{
    for (int idx{}; idx < test_size; ++idx)
    {
        c[idx] = a[idx] + b[idx];
    }
}

/**
 * strict aliasing rule -- UB
*/
[[gnu::noinline]] void restrict_NoUB_vec(float *a, float *b) noexcept
{
    for (int idx{}; idx < test_size; ++idx)
    {
        a[idx] += b[idx];
    }
}

// can produce proper output when vectorization isn't applied :)
[[gnu::noinline]] void restrict_UB_vec(float *__restrict__ a, float *__restrict__ b) noexcept
{
    for (int idx{}; idx < test_size; ++idx)
    {
        a[idx] += b[idx];
    }
}

[[gnu::noinline]] auto restrict_UB(float *a, int *b)
{
    *b = 1;
    *a = 0;

    return *b; // moves 1 instead of &b
}

[[gnu::noinline]] auto restrict_Normal(float *a, float *b)
{
    *b = 1;
    *a = 0;

    return *b;
}

template <int Size>
constexpr auto generate()
{
    std::array<float, Size> x;

    for (int i{}; i < Size; ++i)
    {
        x[i] = i;
    }

    return x;
}

/**
 * __restrict__ drawbacks on type deduction :(
*/
template <typename T>
void template_tester() {}

void drawbacks(float *__restrict__ a, float *b,
               float &__restrict__ a_ref, float &b_ref,
               float (&__restrict__ a_arr)[512], float (&b_arr)[512])
{
    // Very surprising results
    template_tester<std::remove_pointer_t<decltype(a)>>();
    template_tester<std::remove_pointer_t<decltype(b)>>();

    template_tester<std::remove_reference_t<decltype(a_ref)>>();
    template_tester<std::remove_reference_t<decltype(b_ref)>>();

    template_tester<std::remove_reference_t<decltype(a_arr)>>();
    template_tester<std::remove_reference_t<decltype(b_arr)>>();

    // WA
    auto *x = a;
    auto &x_ref = a_ref;
    auto &x_arr = a_arr;
}

int main()
{
    as_if_break();
    eval_order_test();

    {
        auto arr = generate<2 * test_size>();
        restrict_NoUB_vec(arr.data() + 2, arr.data());

        std::cout << "NoUB sequence: ";
        for (const auto &el : arr)
        {
            std::cout << el << ", ";
        }

        std::cout << std::endl
                  << std::endl;
    }

    {
        auto arr = generate<2 * test_size>();
        restrict_UB_vec(arr.data() + 2, arr.data());

        std::cout << "UB sequence: ";
        for (const auto &el : arr)
        {
            std::cout << el << ", ";
        }

        std::cout << std::endl
                  << std::endl;
    }
}
