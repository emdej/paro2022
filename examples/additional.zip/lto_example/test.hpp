#pragma once

void test() noexcept;
