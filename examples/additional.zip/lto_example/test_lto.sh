#! /bin/bash

clang++ -std=c++17 -flto -save-temps -O3 main.cpp test.cpp -o "test"
