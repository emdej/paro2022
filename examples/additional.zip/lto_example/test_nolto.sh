#! /bin/bash

clang++ -std=c++17 -O3 main.cpp test.cpp -o "test"
