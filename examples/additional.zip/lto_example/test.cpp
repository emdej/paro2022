#include "test.hpp"

namespace
{

    int x{10};

}

void test() noexcept
{
    x = 10 * 10 * x;
}
