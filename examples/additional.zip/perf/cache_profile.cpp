
// L1 cache size ==> cat /sys/devices/system/cpu/cpu0/cache/index0/<type,level,size>

// perf record
// perf report

constexpr auto allocation_size = 50000;

auto *cache_spill()
{
    auto *x = new char[allocation_size]{};
    return x;
}

int main()
{
    volatile auto *x = cache_spill();

    for (int i{}; i < 100; ++i)
    {
        for (int idx{}; idx < allocation_size; ++idx)
        {
            x[idx] = 'x';
        }
    }
}
