module;

#include <type_traits>

export module A;

export
{

    template <typename T>
    T add(T x, T y) noexcept
    {
        return x + y;
    }

    auto sub(auto x, auto y) noexcept
    {
        static_assert(std::is_same_v<decltype(x), decltype(y)>);

        return x - y;
    }
}

void foo() {}

// non implemented
// module : private;
