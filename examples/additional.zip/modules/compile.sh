#! /bin/bash

gcc_loc="/home/kubanski/Code/Projects/SDK/SDK-sx86it/compilers-sx86it/gcc11.2.0/gcc-11.2.0-x86_64-linux-gnu-ubuntu-20.04/bin/g++"
${gcc_loc} -std=c++20 -fmodules-ts A.cpp main.cpp
