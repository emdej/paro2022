import A;

#include <iostream>

int main()
{
    std::cout << "add: " << add(5, 10) << std::endl;
    std::cout << "sub: " << sub(5, 10) << std::endl;

    foo();
}
