void deallocate_fail() noexcept
{
    auto *x = new int(5);
}

void access_fail() noexcept
{
    auto *x = new int(5);
    x[1] = 10;
}

int main()
{
    deallocate_fail();
    access_fail();
}
