#include "include/blackmagic.hpp"
int foo2() { return blackmagic<2>(2); }
