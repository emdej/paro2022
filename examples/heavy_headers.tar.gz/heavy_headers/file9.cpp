#include "include/blackmagic.hpp"
int foo9() { return blackmagic<2>(9); }
