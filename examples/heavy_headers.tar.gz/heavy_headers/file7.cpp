#include "include/blackmagic.hpp"
int foo7() { return blackmagic<2>(7); }
