#include "include/blackmagic.hpp"
int foo6() { return blackmagic<2>(6); }
