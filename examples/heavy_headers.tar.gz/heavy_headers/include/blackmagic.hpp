#include <boost/msm/front/euml/euml.hpp>
#include <boost/msm/front/euml/state_grammar.hpp>
#include <boost/msm/back/state_machine.hpp>

namespace msm = boost::msm;
using namespace boost::msm::front::euml;

BOOST_MSM_EUML_STATE((), Off)
BOOST_MSM_EUML_STATE((), On)

BOOST_MSM_EUML_EVENT(press)

BOOST_MSM_EUML_TRANSITION_TABLE((
  Off + press == On,
  On + press == Off
), light_transition_table)

BOOST_MSM_EUML_DECLARE_STATE_MACHINE(
(light_transition_table, init_ << Off),
light_state_machine)


template <int N>
int blackmagic(int x)
{
    static_assert(N > 0);
    msm::back::state_machine<light_state_machine> light;
    for (int i=0; i<x; i++)
    {
        light.process_event(press);
    }
    if constexpr(N == 1)
        return 1;
    else
        return *light.current_state() + blackmagic<N-1>(x-1);
}
