#include "include/blackmagic.hpp"
int foo5() { return blackmagic<2>(5); }
