#include "include/blackmagic.hpp"
int foo8() { return blackmagic<2>(8); }
