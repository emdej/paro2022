#include "include/blackmagic.hpp"
int foo1() { return blackmagic<2>(1); }
