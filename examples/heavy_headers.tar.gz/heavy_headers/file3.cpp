#include "include/blackmagic.hpp"
int foo3() { return blackmagic<2>(3); }
