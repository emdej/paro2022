#include "include/blackmagic.hpp"
int foo10() { return blackmagic<2>(10); }
