int foo1();
int foo2();
int foo3();
int foo4();
int foo5();
int foo6();
int foo7();
int foo8();
int foo9();
int foo10();
int main(){
int x = 0;
x += foo1();
x += foo2();
x += foo3();
x += foo4();
x += foo5();
x += foo6();
x += foo7();
x += foo8();
x += foo9();
x += foo10();
return x;
}
