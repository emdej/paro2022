#include "include/blackmagic.hpp"
int foo4() { return blackmagic<2>(4); }
